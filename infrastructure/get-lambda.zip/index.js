exports.handler = require('./lib/get-lambda')
